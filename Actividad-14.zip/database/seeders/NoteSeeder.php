<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Note;

class NoteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Note::create([
            'title' => 'Nota 1',
            'author' => 'User 1',
            'date_and_time' => '2024-03-20',
            'body_of_the_note' => 'Hola buenos dias',
            'classification' => 'Personal'
        ]);
    }
}
