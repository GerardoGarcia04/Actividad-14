<?php

namespace App\DataTables;

use App\Models\Note;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\Editor\Editor;
use Yajra\DataTables\Html\Editor\Fields;
use Yajra\DataTables\Services\DataTable;

class NoteDataTable extends BlankDataTable
{
	public function __construct()
	{
		$this->routeResource = 'notes';
	}
	/**
	 * Get query source of dataTable.
	 *
	 * @param \App\Selling $model
	 * @return \Illuminate\Database\Eloquent\Builder
	 */
	public function query(Note $model)
	{
		return $model
		->newQuery();
	}

	/**
	 * Get columns.
	 *
	 * @return array
	 */
	protected function getColumns()
	{
		$pColumns = parent::getColumns();
		$columns = [
			['data' => 'id', 'visible' => false, 'title' => __('notes.id')],
			['data' => 'title', 'title' => __('notes.title')],
			['data' => 'author', 'title' => __('notes.author')],
			['data' => 'date_and_time', 'title' => __('notes.date_and_time')],
			['data' => 'body_of_the_note', 'title' => __('notes.body_of_the_note')],
			['data' => 'classification', 'title' => __('notes.classification')],
			['data' => 'created_at', 'visible' => false, 'title' => __('notes.created_at')],
			['data' => 'updated_at', 'visible' => false, 'title' => __('notes.updated_at')],
		];
		return array_merge($columns, $pColumns);
	}
}
