<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Note;
use Illuminate\Http\Request;

class NoteController extends Controller
{
    public function index()
    {
        $notes = Note::all();
        return view('notes.index', compact('notes'));
    }

    public function create()
    {
        return view('notes.create');
    }

    public function store(Request $request)
    {
        $note = new Note;
        $note->title = $request->input('title');
        $note->author = $request->input('author');
        $note->body = $request->input('body');
        $note->category = $request->input('category');
        $note->save();

        return redirect()->route('notes.index');
    }

    public function show($id)
    {
        $note = Note::find($id);
        return view('notes.show', compact('note'));
    }

    public function edit($id)
    {
        $note = Note::find($id);
        return view('notes.edit', compact('note'));
    }

    public function update(Request $request, $id)
    {
        $note = Note::find($id);
        $note->title = $request->input('title');
        $note->author = $request->input('author');
        $note->body = $request->input('body');
        $note->category = $request->input('category');
        $note->save();

        return redirect()->route('notes.index');
    }

    public function destroy($id)
    {
        Note::destroy($id);
        return redirect()->route('notes.index');
    }
}
