<?php

namespace App\Http\Controllers;

use App\Models\Note;

use App\Http\Requests\NoteRequest;
use App\DataTables\NoteDataTable;
use Illuminate\Http\Request;

class NoteController extends Controller
{
	/**
	 * Display a listing of the resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index()
	{
		//Consultar permiso para botón de agregar
		$allowAdd = auth()->user()->hasPermissions("notes.create");
		$allowEdit = auth()->user()->hasPermissions("notes.edit");
		return (new NoteDataTable())->render('notes.index', compact('allowAdd', 'allowEdit'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function create()
	{
		return view('notes.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @return \Illuminate\Http\Response
	 */
	public function store(NoteRequest $request)
	{
		$status = true;
		$note = null;
		$params = array_merge($request->all(), [
			'created_by' => auth()->id(),
			'updated_by' => auth()->id(),
			'created_at' => date("Y-m-d H:i:s"),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$note = Note::create($params);
			$message = __('notes.Successfully created');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'notes');
		}
		return $this->getResponse($status, $message, $note);
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  \App\Note  $note
	 * @return \Illuminate\Http\Response
	 */
	public function show(Note $note)
	{
		return view('notes.show', compact('note'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  \App\Note  $note
	 * @return \Illuminate\Http\Response
	 */
	public function edit(Note $note)
	{
		return view('notes.edit', compact('note'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  \Illuminate\Http\Request  $request
	 * @param  \App\Note  $note
	 * @return \Illuminate\Http\Response
	 */
	public function update(NoteRequest $request, Note $note)
	{
		$status = true;
		$params = array_merge($request->all(), [
			'updated_by' => auth()->id(),
			'updated_at' => date("Y-m-d H:i:s")
		]);
		try {
			$note->update($params);
			$message = __('notes.Successfully updated');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'notes');
		}
		return $this->getResponse($status, $message, $note);
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  \App\Note  $note
	 * @return \Illuminate\Http\Response
	 */
	public function destroy(Note $note)
	{
		$status = true;
		try {
			$note->delete();
			$message = __('notes.Successfully deleted');
		} catch (\Illuminate\Database\QueryException $e) {
			$status = false;
			$message = $this->getErrorMessage($e, 'notes');
		}
		return $this->getResponse($status, $message);
	}

	public function getQuickModalContent(Note $note = null)
	{
		$params = request("params");
		return response()->json(view('crud-maker.components.modal-quickadd', compact('params', 'note'))->render());
	}
}
