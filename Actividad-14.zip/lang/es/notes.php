<?php
return [
	//Titles
	"title_index" => "Notas",
	"title_add" => "Agregar nota",
	"title_show" => "Ver nota",
	"title_edit" => "Modificar nota",
	"title_delete" => "Eliminar nota",

	//Fields
	"id" => "id",
	"title" => "Titulo",
	"author" => "Autor",
	"date_and_time" => "Fecha y hora",
	"body_of_the_note" => "Cuerpo de la nota",
	"classification" => "Clasificación",
	"created_at" => "Fecha creado",
	"updated_at" => "Fecha modificado",

	//Action messages
	"confirm_delete" => "Se borrará nota de la base de datos. ¿Desea continuar?",
	"Successfully created" => "nota creado correctamente",
	"Successfully updated" => "nota modificado correctamente",
	"Successfully deleted" => "nota eliminado correctamente",
	"delete_error_message" => "Error al intentar eliminar nota de la base de datos",
	"delete_error_message_constraint" => "No se puede eliminar nota, hay tablas que dependen de este",
];