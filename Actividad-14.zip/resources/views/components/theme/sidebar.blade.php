<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

	<div data-simplebar class="h-100">

		<!--- Sidemenu -->
		<div id="sidebar-menu">
			<ul class="metismenu list-unstyled" id="side-menu">
				@include('components.theme.sidebar-menus', compact('menus'))
			</ul>
		</div>
	</div>
</div>