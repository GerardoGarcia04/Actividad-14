@extends('layouts.app', [
	'title' => __('notes.title_show'), 
])

@section('content')
<div class="report-container p-3">
	<div class="row">
		<div class="col-sm-12 col-md-6 offset-md-3">
			<br>
			<div class="card card-info">
				<div class="card-header">
					<div class="row">
						<div class="col-sm-12 col-md-6 card-title">@lang('notes.title_show')</div>
						<div class="col-sm-12 col-md-6 text-right">
							<a href="{{ route('notes.index') }}">
								<i class="fas fa-long-arrow-alt-left"></i>
							</a>
						</div>
					</div>
				</div>
				<div class="card-body">
					
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.id')</div>
						<div class="col-sm-6">{{ $note->id }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.title')</div>
						<div class="col-sm-6">{{ $note->title }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.author')</div>
						<div class="col-sm-6">{{ $note->author }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.date_and_time')</div>
						<div class="col-sm-6">{{ $note->date_and_time }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.body_of_the_note')</div>
						<div class="col-sm-6">{{ $note->body_of_the_note }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.classification')</div>
						<div class="col-sm-6">{{ $note->classification }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.created_at')</div>
						<div class="col-sm-6">{{ $note->created_at }}</div>
					</div>
					<div class="row">
						<div class="col-sm-4 offset-sm-1 text-end">@lang('notes.updated_at')</div>
						<div class="col-sm-6">{{ $note->updated_at }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection