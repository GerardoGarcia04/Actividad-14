@extends('crud-maker.layouts.index', [
	'title' => __('notes.title_index'), 
	'entity' => 'notes', 
	'form' => 'note',
])

@section('datatable')
	{{ $dataTable->table(["width" => "100%"]) }}
@endsection