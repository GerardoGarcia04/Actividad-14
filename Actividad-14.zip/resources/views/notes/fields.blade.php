@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "title",
		"id" => "title",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("title") ?? ($note->title ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "author",
		"id" => "author",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("author") ?? ($note->author ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "date_and_time",
		"id" => "date_and_time",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("date_and_time") ?? ($note->date_and_time ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "body_of_the_note",
		"id" => "body_of_the_note",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("body_of_the_note") ?? ($note->body_of_the_note ?? ""),
		"required" => "true",
	]
]])
@include("crud-maker.components.form-row", ["params" => [
	[
		"name" => "classification",
		"id" => "classification",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("classification") ?? ($note->classification ?? ""),
		"required" => "true",
	]
]])
