<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li>
		<a href="<?php echo e($menu["viewname_id"] == NULL ? 'javascript: void(0);' : route($menu['link'])); ?>" class="waves-effect">
			<?php echo $menu["icon"]; ?>

			<span key="t-dashboards"><?php echo app('translator')->get($menu["name"].".title_index"); ?></span>
		</a>

		<?php if(!empty($menu["submenus"])): ?>
		<ul class="sub-menu" aria-expanded="false">
			<?php echo $__env->make('components.theme.sidebar-menus', ["menus" => $menu["submenus"]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</ul>
		<?php endif; ?>
	</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/components/theme/sidebar-menus.blade.php ENDPATH**/ ?>