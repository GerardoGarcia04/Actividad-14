

<?php $__env->startSection('content'); ?>
<div class="row height-100">
	<div class="col-12 col-md-8 offset-md-2">
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<div id="message" class="row  flex-shrink-0 flex-row ">
			<div class="col-12 col-md-4 offset-md-4">
				<div class="message-container"></div>
				<?php if(session()->has('status')): ?>
					<div class="alert alert-info dismissible">
						<button type="button" class="btn btn-default" data-bs-dismiss="alert" aria-label="Close">
							<i class="mdi mdi-window-close icon-edit font-size-18"></i>
						</button>
						<?php echo session()->get('status'); ?>

					</div>
				<?php endif; ?>
				<?php echo $__env->make('crud-maker.components.session-alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
		</div>
		<div class="row">
			<div class="col-12 col-md-4 offset-md-4 login-form">
				<div class="row login-header">
					<div class="col-12 p-4">
						<?php echo $__env->yieldContent('header'); ?>
					</div>
				</div>
				<?php if($floatingIcon ?? true): ?>
				<div class="login-floating-icon p-3">
					<img src="images/login-icon.png" alt="">
				</div>
				<?php endif; ?>
				<div class="row p-4 login-body">
					<?php echo $__env->yieldContent('body'); ?>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12 col-md-4 offset-md-4">
				<?php echo $__env->yieldContent('footer'); ?>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/layouts/login.blade.php ENDPATH**/ ?>