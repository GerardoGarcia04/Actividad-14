

<?php $__env->startSection('datatable'); ?>
	<?php echo e($dataTable->table(["width" => "100%"])); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('crud-maker.layouts.index', [
	'title' => __('notes.title_index'), 
	'entity' => 'notes', 
	'form' => 'note',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/notes/index.blade.php ENDPATH**/ ?>