
<?php
	$params["class"] = $params["class"] ?? 'form-control';
	/* En caso de que el nombre del campo sea un nombre raro como por ejemmplo users[email]
		Para poner el texto en el placeholder se buscará "id" en los parámetros */
	$name = $params["id"] ?? $params["name"];
	$params["placeholder"] = __($params["translations"] ?? ($params["entity"].".".$name));
	$quickadd = $params["quickadd"] ?? [];
	$addonButton = $params["addonButton"] ?? false;
	unset($params["quickadd"]);
	unset($params["addonButton"]);
?>

<?php if($addonButton != false): ?>
<div class="input-group">
<?php elseif($quickadd ?? false): ?>
<div class="input-group">
<?php endif; ?>

<?php if(isset($params["type"])): ?>
	<?php switch($params["type"]):
		case ('date'): ?>
			<?php echo e(Form::date($params["name"], $params["defaultValue"] ?? "", $params)); ?>

			<?php break; ?>
		<?php case ('datepicker'): ?>
			<?php echo $__env->make('crud-maker.components.field-datetimepicker', compact('params'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php break; ?>
		<?php case ('input-autocomplete'): ?>
			<?php echo $__env->make('crud-maker.components.field-autocomplete-input', compact('params'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php break; ?>
		<?php case ('select'): ?>
			<?php
				//Quitamos de los parámetros el array con los elementos que rellenará el select
				$elements = $params["elements"];
				unset($params["elements"]);
				//Quitamos placeholder para que no nos agregue elemento vacío al inicio
				unset($params["placeholder"]);
			?>
			<?php echo e(Form::select($params["name"], $elements, $params["defaultValue"] ?? "", $params)); ?>

			<?php break; ?>
		<?php case ('number'): ?>
			<?php echo e(Form::number($params["name"], $params["defaultValue"] ?? "", $params)); ?>

			<?php break; ?>
		<?php case ('textarea'): ?>
			<?php echo e(Form::textarea($params["name"], $params["defaultValue"] ?? "", $params)); ?>

			<?php break; ?>
		<?php case ('text'): ?>
			<?php echo e(Form::text($params["name"], $params["defaultValue"] ?? "", $params)); ?>

			<?php break; ?>
		<?php case ('text-div'): ?>
			<?php echo $__env->make('crud-maker.components.field-text-div', compact('params'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php break; ?>
		<?php case ('password'): ?>
			<?php echo e(Form::password($params["name"], $params)); ?>

			<?php break; ?>
		<?php case ('checkbox'): ?>
			<?php echo $__env->make('crud-maker.components.field-checkbox', compact('params'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php break; ?>
		<?php case ('radio'): ?>
			<?php echo $__env->make('crud-maker.components.field-radio', compact('params'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php break; ?>
		<?php case ('label'): ?>
			<?php echo e(Form::label($params["name"], $params["defaultValue"] ?? "", $params)); ?>

			<?php break; ?>
	<?php endswitch; ?>
<?php else: ?>
	<?php echo e(Form::text($params["name"], "", $params)); ?>

<?php endif; ?>

<?php if($addonButton != false): ?>
	<div class="input-group-append">
		<?php echo e(Form::button($addonButton["name"], $addonButton)); ?>

	</div>
</div>
<?php elseif($quickadd ?? false): ?>
	<div class="input-group-append">
		<?php echo e(Form::button($quickadd["text"] ?? '<i class="fas fa-plus"></i></button>', array_merge(["class" => "btn btn-secondary"], ($quickadd["props"] ?? [])))); ?>

	</div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/crud-maker/components/field-add.blade.php ENDPATH**/ ?>