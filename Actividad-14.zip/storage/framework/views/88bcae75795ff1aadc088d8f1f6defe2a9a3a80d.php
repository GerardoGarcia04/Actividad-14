<div class="col-12 mt-4">
	<div class="alert alert-success d-none" role="alert"></div>
	<form method="POST" action="<?php echo e(route('login')); ?>">
		<?php echo csrf_field(); ?>
		<div class="row">
			<div class="col">
				<label for="email" class="col-form-label text-lg-right text-secondary">
					<?php echo app('translator')->get('auth.email'); ?>
				</label>
			</div>
		</div>
		<div class="row mb-4">
			<div class="col">
				<input id="email" type="email" class="form-control input-login <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> input" 
					name="email" required autocomplete="email" placeholder="<?php echo app('translator')->get('E-Mail Address'); ?>" value="<?php echo e(old('email')); ?>" autofocus>

				<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
		</div>

		<div class="row">
			<div class="col">
			<label for="password" class="col-form-label text-md-right text-secondary">
				<?php echo app('translator')->get('auth.password'); ?>
			</label>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<input id="password" type="password" class="form-control input-login <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> input" 
					name="password" required autocomplete="current-password" placeholder="<?php echo app('translator')->get('Password'); ?>">

				<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback" role="alert">
						<strong><?php echo e($message); ?></strong>
					</span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
		</div>
		<div class="row">
			<div class="col-12 pt-4">
				<input type="checkbox" name="remember" id="remember">
				<label for="remember"><?php echo app('translator')->get('auth.remember_me'); ?></label>
			</div>
		</div>
		<div class="row mt-4">
			<div class="col-12">
				<button type="submit" class="w-100 btn btn-primary">
					<?php echo app('translator')->get('auth.login_button'); ?>
				</button>
			</div>
		</div>
		<div class="row mt-4">
			<div class="col-12 col-md-12 text-center">
				<?php if(Route::has('password.request')): ?>
					<a class="app-link" href="<?php echo e(route('password.request')); ?>">
						<i class='bx bxs-lock-alt'></i>
						<?php echo app('translator')->get('auth.password_recover'); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</form>
</div><?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/auth/login-fields.blade.php ENDPATH**/ ?>