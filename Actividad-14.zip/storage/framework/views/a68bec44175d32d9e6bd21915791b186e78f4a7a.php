<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "title",
		"id" => "title",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("title") ?? ($note->title ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "author",
		"id" => "author",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("author") ?? ($note->author ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "date_and_time",
		"id" => "date_and_time",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("date_and_time") ?? ($note->date_and_time ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "body_of_the_note",
		"id" => "body_of_the_note",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("body_of_the_note") ?? ($note->body_of_the_note ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("crud-maker.components.form-row", ["params" => [
	[
		"name" => "classification",
		"id" => "classification",
		"class" => "form-control",
		"entity" => "notes",
		"type" => "text",
		"defaultValue" => old("classification") ?? ($note->classification ?? ""),
		"required" => "true",
	]
]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/notes/fields.blade.php ENDPATH**/ ?>