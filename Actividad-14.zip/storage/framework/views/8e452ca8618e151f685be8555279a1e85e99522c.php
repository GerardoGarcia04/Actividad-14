
<div class="row mb-3">
	<?php 
		$cols = $cols ?? count($params);
		$displayInline = $cols > 1 ? true : false;
	?>
	<?php for($i = 0; $i < $cols; $i++): ?>
		<?php if(isset($params[$i])): ?>
			<?php 
				$isRequired = $params[$i]["required"] ?? false;
			?>
			<div class="col-12 col-md-<?php echo e($displayInline ? (12 / floatval($cols)) : 12); ?>">
				
				<div class="row <?php echo e($params[$i]["name"]); ?>_container" style="display: <?php echo e($params[$i]["display"] ?? "flex"); ?>;">
					<label for="<?php echo e($params[$i]["name"]); ?>" class="col-12 col-md-<?php echo e($displayInline ? 5 : 12); ?> control-label">
						<?php echo e(__($params[$i]["translations"] ?? $params[$i]["entity"].".".$params[$i]["name"])); ?> 
						<?php if($isRequired): ?> <span class="required">*</span> <?php endif; ?>
					</label>
					<div class="col-12 col-md-<?php echo e($displayInline ? 7 : 12); ?>">
						<?php echo $__env->make('crud-maker.components.field-add', ['params' => $params[$i]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</div>
				
			</div>
		<?php endif; ?>
	<?php endfor; ?>
</div>
<?php /**PATH C:\xampp\htdocs\actividad-14\resources\views/crud-maker/components/form-row.blade.php ENDPATH**/ ?>